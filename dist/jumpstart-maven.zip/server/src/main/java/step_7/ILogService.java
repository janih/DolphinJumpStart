package step_7;

public interface ILogService {
    void log(Object message);
}
